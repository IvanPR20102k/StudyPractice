﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _20_102k_Shipelkin_Practice.Entities;

namespace _20_102k_Shipelkin_Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        public Authorization()
        {
            InitializeComponent();
        }

        private void btnLogIn_Click(object sender, RoutedEventArgs e)
        {
            string login = tbLogin.Text.Trim();
            string password = passwordBox.Password.Trim();

            Employees employee = Entities.Entities.GetContext().Employees.Where(p => p.EmployeeLogin == login && p.EmployeePassword == password).FirstOrDefault();
            if (employee != null)
            {
                MessageBox.Show("Вы вошли под " + employee.Roles.RoleName.ToString());
                NavigationService.Navigate(new Table());
            }
            else
            {
                MessageBox.Show("Неверо введён логин или пароль!");
                passwordBox.Password = "";
            }
        }
    }
}
