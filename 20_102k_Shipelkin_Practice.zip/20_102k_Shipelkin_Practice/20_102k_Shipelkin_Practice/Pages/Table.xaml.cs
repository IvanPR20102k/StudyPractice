﻿using _20_102k_Shipelkin_Practice.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _20_102k_Shipelkin_Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для Table.xaml
    /// </summary>
    public partial class Table : Page
    {
        public Table()
        {
            InitializeComponent();
            DGridEmployees.ItemsSource = Entities.Entities.GetContext().Employees.ToList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditPage((sender as Button).DataContext as Employees));
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new EditPage(null));
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var employeesForRemoving = DGridEmployees.SelectedItems.Cast<Employees>().ToList();
            if (MessageBox.Show($"Поддтвердите удаление {employeesForRemoving.Count()} элементов?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    Entities.Entities.GetContext().Employees.RemoveRange(employeesForRemoving);
                    Entities.Entities.GetContext().SaveChanges();
                    MessageBox.Show("Данные успешно удалены");

                    DGridEmployees.ItemsSource = Entities.Entities.GetContext().Employees.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                Entities.Entities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridEmployees.ItemsSource = Entities.Entities.GetContext().Employees.ToList();
            }
        }
    }
}
